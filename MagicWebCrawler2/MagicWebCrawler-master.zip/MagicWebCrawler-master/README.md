# MagicWebCrawler
Based on DRKSpider 4.0


package com.droegec.mwc.exceptions;

public class RobotsNotFoundException extends Exception {

	private static final long serialVersionUID = -8884894485579590108L;

}
